function addFun(v1,v2){
    return (v1+v2);
}
function subFun(v1,v2){
    return (v1-v2);
}
function mulFun(v1,v2){
    return (v1*v2);
}
function divFun(v1,v2){
    return (v1/v2);
}
function modFun(v1,v2){
    return (v1%v2);
}
function sqrtFun(v1){
    return Math.sqrt(v1)
}
function performOperation(v1,v2,operation){
            
                switch(operation)
                {
                case '+':
                return addFun(v1,v2);
             
                case '-':
                return subFun(v1,v2);
               
                case 'x':
                return mulFun(v1,v2);
               
                case '/':
                return divFun(v1,v2);
               
                case '%':
                return modFun(v1,v2);
               
                case 'sqrt':
                return sqrtFun(v1);

                default:
                alert("Cannot be performed");
                } 
}