/*var emp = {};
emp.empId = 101;
emp.empName = "Akbhar";
emp.empRole = "king";

console.log(emp);
console.log(emp.empName);
console.log(emp.empRole);

var emp2 = emp;
emp.empName="Shajahan";
console.log(emp);*/
////////////////////////////////////other way
let employee = function(id, role, place){
    this.id = id;
    this.role = role;
    this.place = place;
    this.display = function(){
        $(this.id);
        $(this.role);
        $(this.place);
    }
}/*
let emp1 = new employee(123,"rrc","tanjore");
let emp2 = new employee(124,"kkc","coimatore");

emp1.display();
emp2.display();
//////////////////////////////////////////// input from 
*/

