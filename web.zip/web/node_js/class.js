class employee{
    constructor(id,name,address)
    {
        this.id = id;
        this.name = name;
        this.address = address;
    }
    display(){
        const data = `${this.id} number ${this.name} from ${this.address}`;
        console.log(data);
    }

}
const obj = new employee(1,"rmv","chennai");
obj.display();