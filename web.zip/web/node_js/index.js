//var fruit = "apple";
let fruit = "apple";

function addFruit(fname){
    //var fruit = fname;
    let fruit = fname;
    console.log(fruit);
    console.log("added");
}
const data ="123";
console.log(data);
addFruit("orange");
console.log("old fruit:" + fruit);

const arr = [1,2,3,4,5,6,4436,6547334,354]
for  (const element of arr){
    console.log(element);
}

function addFunc(v1,v2=20)
{
    var res = v1+v2;
    console.log("added value: "+ res);
}
addFunc(100);

/*function addName(name){
    return `${name}`;
} */

/*const getName = function(name){
    return `${name}`;
}

console.log(getName("someone"));
*/
const getName = (name) => `${name}`;
const addFuncn = (v1,v2) => v1 + v2;
const addSub = (v1,v2) => v1 - v2;

console.log(getName("Tamasha"));
console.log(addFuncn(10,11));
console.log(addSub(20,10));

const strVal = `this is a very small code
where it is easy to learn
and helps in`
console.log(strVal);

/////destructing
function emp(val1,val2){
    this.name = val1;
    this.address = val2;
}
let{name,address} = new emp("rmv","chennai");
console.log(`${name} comes from ${address}`);