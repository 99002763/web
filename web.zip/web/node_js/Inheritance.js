class Account{
    constructor(no, name, amount){
        this.no = no;
        this.name = name;
        this.balance = amount;
    }

    credit(amount){
        this.balance += amount;
    }
    debit(amount){
        if(this.balance<amount){
            throw "Minimal balance";
        }
        this.balance -= amount;
    }
}

class SBAccount extends Account{
    calcInterest(){
        let principle = this.balance;
        const RateOfInterest = 6.5/100;
        const year =2;
        const interest = (principle * RateOfInterest * year);
        this.credit(interest);
    } 
}
try{
    const account = new SBAccount(1234,'GOOGLE',50000);
    //account.credit(100000);
    //account.debit(5000);
    account.calcInterest();
    console.log("The balance:" + account.balance);
}catch(err){
    console.log(err);
}