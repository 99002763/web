const fs = require('fs');

//const data = fs.readFileSync("market.js", "utf-8");

//console.log(data);

fs.readFile("readFile.js","utf-8",(err,data)=>{
    if(err!=null ) 
        console.log(err.message);
    else{
        console.log(data);
    }
});

console.log("File reading gng on");

const filename = "Test.txt";
const emp = `123,rmv,chennai,2021`
fs.writeFileSync(filename,emp,"utf-8");

const emp2 = `empid,rmv,chennai,2021`
fs.appendFileSync(filename,emp2,"utf-8");