/*const readLine = require('readline').createInterface({
    input: process.stdin,
    output: process.stdout
});

readLine.question("What is the req name?",answer =>{
    console.log(answer);
    readLine.close();
})
*/

const os = require('os');
console.log(os.hostname());
console.log(os.type());
console.log(os.version());
console.log(os.uptime()/3600);

console.table([
    {Name:'abc', Address: 'cbe',state:'tn'},
    {Name:'cde', Address: 'blore',state:'kar'},
    {Name:'efg', Address: 'chennai',state:'tn'}
])