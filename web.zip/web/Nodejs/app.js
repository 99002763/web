/*const mulFun = (v1,v2) => v1 * v2;
console.log(mulFun(12,12));
*/

var flipkart = require('./market')();

flipkart.addRecord({"id": 111, "name":"Samsung", "price" : 30000});

const data = flipkart.getAll();
for (const iterator of data){
    console.log(iterator.name);
}